const MENU_SHEET = 'Menu';
const ORDERS_SHEET = 'Orders';
function doGet() { return HtmlService.createHtmlOutputFromFile('Index').setTitle('Daily Meal l').addMetaTag('viewport','width=device-width, initial-scale=1'); }
function setupDailyMeal() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let menu = ss.getSheetByName(MENU_SHEET) || ss.insertSheet(MENU_SHEET);
  menu.clear();
  menu.getRange(1,1,1,7).setValues([['ID','Dish','Category','Price (₹)','Display Price','Available','Description']]);
  menu.getRange(2,1,9,7).setValues([
    ['roti','Plain roti','Roti & Paratha',9,'₹8–10',true,'Per piece'],
    ['paratha','Plain paratha','Roti & Paratha',15,'₹15',true,'Per piece'],
    ['methi','Methi paratha','Roti & Paratha',18,'₹15–20',true,'Per piece'],
    ['soy-pulao','Soyabean pulao','Rice',70,'₹70',true,'Full portion'],
    ['dal-fry','Dal fry','Sabji & Sides',45,'₹45',true,'Full portion'],
    ['bharta','Bharta','Sabji & Sides',50,'₹50',true,'Full portion'],
    ['aloo-matar','Aloo matar sabji','Sabji & Sides',45,'₹45',true,'Full portion'],
    ['tomato-chutney','Tomato chutney','Sabji & Sides',25,'₹25',true,'One portion'],
    ['combo','Paratha Special Tiffin','Tiffin Meal',240,'₹240',true,'4 parathas + dal fry + bharta + soyabean pulao']
  ]);
  menu.setFrozenRows(1); menu.autoResizeColumns(1,7); menu.getRange('A1:G1').setFontWeight('bold').setBackground('#1f6b45').setFontColor('#ffffff');
  let orders = ss.getSheetByName(ORDERS_SHEET) || ss.insertSheet(ORDERS_SHEET);
  orders.clear();
  orders.getRange(1,1,1,10).setValues([['Timestamp','Order ID','Customer','Phone','Order Type','Fulfilment','Payment','Items','Total (₹)','Notes / Address']]);
  orders.setFrozenRows(1); orders.autoResizeColumns(1,10); orders.getRange('A1:J1').setFontWeight('bold').setBackground('#1f6b45').setFontColor('#ffffff');
  return 'Setup complete. Edit prices in the Menu tab. Keep Price numeric; Display Price is what customers see.';
}
function getMenu() {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(MENU_SHEET);
  if (!sh || sh.getLastRow() < 2) return [];
  return sh.getRange(2,1,sh.getLastRow()-1,7).getValues().filter(r => r[0] && r[5] === true).map(r => ({id:String(r[0]),name:String(r[1]),category:String(r[2]),price:Number(r[3])||0,displayPrice:String(r[4]||('₹'+r[3])),available:r[5]===true,description:String(r[6]||'')}));
}
function submitOrder(order) {
  if (!order || !order.name || !order.phone || !Array.isArray(order.items) || !order.items.length) throw new Error('Please provide your name, phone and at least one item.');
  if (!['Individual meal','Daily tiffin subscription'].includes(order.orderType)) throw new Error('Invalid order type.');
  if (!['Home delivery','Pickup'].includes(order.fulfilment)) throw new Error('Invalid fulfilment.');
  if (!['UPI','Cash'].includes(order.payment)) throw new Error('Invalid payment choice.');
  const menu = getMenu(); const byId = Object.fromEntries(menu.map(i=>[i.id,i])); let lines=[]; let total=0;
  order.items.forEach(x=>{const item=byId[String(x.id)]; const qty=Math.max(0,Math.min(100,Math.floor(Number(x.qty)||0))); if(item && qty){lines.push(qty+' × '+item.name+' (₹'+item.price+' each)');total+=item.price*qty;}});
  if (!lines.length) throw new Error('No available menu items found. Please refresh the menu.');
  if (order.fulfilment==='Home delivery' && !String(order.address||'').trim()) throw new Error('Please enter your delivery address.');
  const sh=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(ORDERS_SHEET); const orderId='DM-'+Date.now().toString().slice(-8);
  sh.appendRow([new Date(),orderId,String(order.name).slice(0,100),String(order.phone).slice(0,25),order.orderType,order.fulfilment,order.payment,lines.join('\n'),total,(String(order.address||'')+' '+String(order.notes||'')).trim().slice(0,1000)]);
  return {ok:true,orderId,total};
}
