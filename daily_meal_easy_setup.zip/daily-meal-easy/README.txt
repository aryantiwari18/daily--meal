DAILY MEAL l — EASY ANDROID SETUP

This version uses Google Sheets as the owner-editable menu/order database and Google Apps Script to host the mobile-friendly website. You don't need GitHub Pages for this version.

FILES
- Code.gs: server functions
- Index.html: customer website

SETUP ON ANDROID
1. Open https://sheets.google.com in Chrome. Create a blank spreadsheet named Daily Meal l Orders.
2. In the spreadsheet, open Extensions > Apps Script. If using a phone, Chrome menu > Desktop site may help.
3. Replace the default contents of Code.gs with the provided Code.gs file contents.
4. Add an HTML file using + > HTML; name it exactly Index. Paste Index.html contents into it.
5. Save the project.
6. In the Apps Script editor, choose setupDailyMeal in the function dropdown and tap Run. Approve the requested Google permissions. This creates Menu and Orders tabs with starter dishes.
7. Go back to the spreadsheet. In the Menu tab, edit the Price (₹) column to the numeric amount used for cart calculations. Edit Display Price to change what customers see. For example Plain roti Price=9 and Display Price=₹8–10; methi paratha Price=18 and Display Price=₹15–20. Set Available to TRUE/FALSE to show/hide a dish. Add a row for a new dish with unique ID, dish, category, numeric price, display price, TRUE, and description.
8. In Apps Script, tap Deploy > New deployment > select type Web app. Execute as: Me. Who has access: Anyone. Tap Deploy and copy the URL ending in /exec.
9. Open the URL on your phone to test the menu and submit a test order. Orders appear in the Orders sheet.
10. Share the /exec URL with customers.

OWNER PRICE CHANGES
Just edit the Menu tab in your Google Sheet. The website refreshes its menu when the customer taps Refresh menu or reloads the page. No redeployment is needed for price changes.

IMPORTANT
- Anyone with the public website URL can submit order requests. Do not put private customer/order data on the public menu page.
- The website runs as your Google account so customer order submissions are saved to your sheet. Do not share editor access to the spreadsheet with customers.
- UPI is only a payment preference; the website does not process or verify payments.
- Test with a fake order before sharing widely. Consider spam protection and stronger validation before scaling.
- Current suggested prices other than roti/paratha are placeholders; adjust them in the Menu sheet.
